<?php return array('dependencies' => array('wp-blocks'), 'version' => '25982af4dc6107c74549');
