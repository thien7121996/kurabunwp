<p><?php esc_html_e( $content ); ?></p>
