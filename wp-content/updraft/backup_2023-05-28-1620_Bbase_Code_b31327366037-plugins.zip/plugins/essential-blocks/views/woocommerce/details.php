<p class="eb-woo-product-details">
    <?php echo wp_trim_words( get_the_content(), $productDescLength ); ?>
</p>
