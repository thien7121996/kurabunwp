<h3 class="eb-woo-product-title">
    <a href="<?php esc_attr_e(esc_url(get_permalink())); ?>">
        <?php esc_html_e( get_the_title() ); ?>
    </a>
</h3>
