<?php return array('dependencies' => array(), 'version' => 'a5db426467a4bfcbf89f');
