<?php return array('dependencies' => array('react', 'wp-element'), 'version' => 'bfb23a247e994d875f75');
