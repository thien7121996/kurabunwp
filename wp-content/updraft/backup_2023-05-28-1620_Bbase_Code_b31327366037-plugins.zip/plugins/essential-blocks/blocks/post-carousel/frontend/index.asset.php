<?php return array('dependencies' => array('wp-api-fetch'), 'version' => 'd82e9fff1ab2bd6f7d5d');
