<?php return array('dependencies' => array(), 'version' => 'e99ba1ccfe82d3eb81d4');
