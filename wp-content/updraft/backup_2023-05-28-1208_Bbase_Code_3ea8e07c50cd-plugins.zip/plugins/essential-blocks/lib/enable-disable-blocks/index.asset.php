<?php return array('dependencies' => array('wp-blocks'), 'version' => '49f82289bac4ec44c202');
