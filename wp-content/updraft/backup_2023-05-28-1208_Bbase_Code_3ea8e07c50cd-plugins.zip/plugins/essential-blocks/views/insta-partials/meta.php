<div class="eb-instagram-meta">
    <span class="dashicons dashicons-clock"></span>
    <span class="eb-instagram-date">
        <?php esc_html_e(date("d M Y", strtotime($timestamp))); ?>
    </span>
</div>
