<?php
    /**
     * @var string $caption
     */
?>
<div class="eb-instagram-caption">
    <p><?php esc_html_e( $caption ); ?></p>
</div>
