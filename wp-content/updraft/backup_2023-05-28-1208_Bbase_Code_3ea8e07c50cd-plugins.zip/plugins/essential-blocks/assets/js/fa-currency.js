const currencyIcons = [
	"fab fa-bitcoin",
	"fab fa-btc",
	"fas fa-dollar-sign",
	"fab fa-ethereum",
	"fas fa-euro-sign",
	"fab fa-gg",
	"fab fa-gg-circle",
	"fas fa-hryvnia",
	"fas fa-lira-sign",
	"fas fa-money-bill",
	"fas fa-money-bill-alt",
	"fa fa-money-bill-wave",
	"fa fa-money-bill-wave-alt",
	"fas fa-money-check",
	"fas fa-money-check-alt",
	"fas fa-pound-sign",
	"fas fa-ruble-sign",
	"fas fa-rupee-sign",
	"fas fa-shekel-sign",
	"fas fa-tenge",
	"fas fa-won-sign",
	"fas fa-yen-sign"
];

export default currencyIcons;
