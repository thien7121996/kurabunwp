<?php return array('dependencies' => array(), 'version' => '74aebaf1200a50347cba');
