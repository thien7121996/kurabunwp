<?php return array('dependencies' => array(), 'version' => '77ce2922a4f497e3fdd3');
