<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '6a329a65aca4c17d4e57');
