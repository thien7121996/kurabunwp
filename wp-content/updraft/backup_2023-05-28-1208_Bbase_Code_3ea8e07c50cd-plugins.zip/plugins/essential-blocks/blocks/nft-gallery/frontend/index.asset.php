<?php return array('dependencies' => array('lodash', 'wp-element'), 'version' => '62670efc61e1631780c4');
