<?php return array('dependencies' => array('wp-api-fetch'), 'version' => 'e96061258b29f79258ff');
