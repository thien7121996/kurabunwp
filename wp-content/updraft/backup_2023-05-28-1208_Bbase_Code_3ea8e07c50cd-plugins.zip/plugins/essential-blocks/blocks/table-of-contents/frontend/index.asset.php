<?php return array('dependencies' => array(), 'version' => 'b28955d4d263653eaf52');
