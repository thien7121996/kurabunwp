<?php return array('dependencies' => array('wp-api-fetch'), 'version' => '81ce9b0ce06f329725d5');
