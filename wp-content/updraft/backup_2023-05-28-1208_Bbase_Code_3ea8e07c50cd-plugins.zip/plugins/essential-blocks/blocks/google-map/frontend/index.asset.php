<?php return array('dependencies' => array(), 'version' => 'c63d1dd8e077e231ff8e');
