<?php return array('dependencies' => array(), 'version' => '557837882350e25c8f46');
