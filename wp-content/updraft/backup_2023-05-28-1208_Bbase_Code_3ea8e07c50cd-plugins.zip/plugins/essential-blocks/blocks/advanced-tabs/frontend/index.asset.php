<?php return array('dependencies' => array(), 'version' => 'eadb31f1ba0eda8efb72');
