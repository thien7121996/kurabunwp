<?php return array('dependencies' => array(), 'version' => 'c185a1b8f9b0c6f9544d');
