<?php return array('dependencies' => array(), 'version' => 'f9624730a013d1d95070');
