<?php return array('dependencies' => array(), 'version' => 'dc6da8a94102e61646c6');
