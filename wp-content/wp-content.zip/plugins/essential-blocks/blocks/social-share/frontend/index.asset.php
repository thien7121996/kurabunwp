<?php return array('dependencies' => array(), 'version' => '2e1a6b55bd98ad9c376a');
