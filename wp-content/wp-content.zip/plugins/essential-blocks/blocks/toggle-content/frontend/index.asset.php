<?php return array('dependencies' => array(), 'version' => '5b465d7b2fa206e469b4');
