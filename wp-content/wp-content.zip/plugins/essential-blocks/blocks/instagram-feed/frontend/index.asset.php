<?php return array('dependencies' => array(), 'version' => '3cc43d801d2a60370e39');
