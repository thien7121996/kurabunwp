<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '4bb3af7d615d83686654');
