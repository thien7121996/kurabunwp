jQuery(document).ready(function($) {
	$(".tbang-loading").fadeOut();
});